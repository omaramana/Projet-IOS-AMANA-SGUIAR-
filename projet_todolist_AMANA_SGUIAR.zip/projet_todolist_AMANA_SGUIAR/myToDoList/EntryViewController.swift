//
//  EntryViewController.swift
//  myToDoList
//
//  Created by Omar Amana on 09/11/2022.
//

import UIKit

class EntryViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var field: UITextField!
    
    @IBOutlet weak var champDescription: UITextField!
    
    
    @IBOutlet weak var datePicker: UIDatePicker!
    var data : ToDo!
    override func viewDidLoad() {
        super.viewDidLoad()
        field.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        
        data = ToDo(nomTache: field.text!, etatTache: false, descriptionTache: champDescription.text!, dateTache: formatter.string(from: datePicker.date))
        
    }

}
