//
//  ViewController.swift
//  myToDoList
//
//  Created by Omar Amana on 09/11/2022.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet var tableView: UITableView!
    
    var tasks : [ToDo] = [ToDo(nomTache: "Acheter du lait", etatTache: true, descriptionTache: "A Carrefour", dateTache: "12/01/2023"), ToDo(nomTache: "Acheter du pain", etatTache: false, descriptionTache: "A la boulangerie", dateTache: "13/01/2023"), ToDo(nomTache: "Acheter de la viande", etatTache: true, descriptionTache: "Chez le boucher", dateTache: "21/01/2023")]
    
    var filteredTasks: [ToDo]!
    
 
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.title = "Title"
        
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.delegate = self
        
        //setup
        
        if !UserDefaults().bool(forKey: "setup"){
            UserDefaults().set(true, forKey: "setup")
            UserDefaults().set(0, forKey: "count")
            
        }
        
        
        filteredTasks = tasks
        tableView.reloadData()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()

    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
            let conf = UISwipeActionsConfiguration(actions: [UIContextualAction(style: .destructive, title: "Delete", handler: {(action, view, completionHandler) in
                let row = indexPath.row
                self.filteredTasks.remove(at: row)
                self.tasks = self.filteredTasks

                completionHandler(true)
                self.tableView.reloadData()
            })])
                return conf
        }
    
    @IBAction func unwindToAdd(_ unwindSegue: UIStoryboardSegue) {
        
        if let vc = unwindSegue.source as? EntryViewController{
            
            if let todo = vc.data{
                filteredTasks.append(todo)
                tasks.append(todo)

                tableView.reloadData()
            }
        }
        
            // Use data from the view controller which initiated the unwind segue
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? TaskViewController { let row = tableView.indexPathForSelectedRow!.row
            vc.data = filteredTasks[row]
            
        }
    }
}



extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return tasks.count
        print(filteredTasks.count)
        return filteredTasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        //cell.textLabel?.text = tasks[indexPath.row]
        //cell.textLabel?.text = filteredTasks[indexPath.row].
        
        cell.textLabel?.text = filteredTasks[indexPath.row].nomTache
       
        if  (filteredTasks[indexPath.row].etatTache) {
            cell.accessoryType = UITableViewCell.AccessoryType.checkmark
        }
        
        else {
            cell.accessoryType = UITableViewCell.AccessoryType.none
        }

        
        return cell
    }
    
    
}

extension ViewController: UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        filteredTasks = []
        
        if searchText == "" {
            
            filteredTasks = tasks
            
        }
        
        for word in tasks {
            
            if
            
                word.nomTache.uppercased().contains(searchText.uppercased()){
                
                filteredTasks.append(word)
                
            }
        }
        tableView.reloadData()
            
    }
}


