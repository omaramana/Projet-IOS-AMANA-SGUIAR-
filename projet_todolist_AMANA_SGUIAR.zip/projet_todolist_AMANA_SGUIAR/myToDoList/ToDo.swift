//
//  ToDo.swift
//  myToDoList
//
//  Created by Omar Amana on 12/01/2023.
//

import Foundation

class ToDo {
    
    var nomTache: String
    var etatTache: Bool
    var descriptionTache: String
    var dateTache: String
    
    init(nomTache: String, etatTache: Bool, descriptionTache: String, dateTache: String) {
        
        self.nomTache = nomTache
        self.etatTache = etatTache
        self.descriptionTache = descriptionTache
        self.dateTache = dateTache
    
    }
    
}
