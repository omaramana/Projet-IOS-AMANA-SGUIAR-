//
//  TaskViewController.swift
//  myToDoList
//
//  Created by Omar Amana on 09/11/2022.
//

import UIKit

class TaskViewController: UIViewController {
    
    @IBOutlet var label: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBAction func switchDone(_ sender: Any) {
        data!.etatTache = !data!.etatTache
    }
    
    @IBOutlet weak var switchVertGris: UISwitch!

    var data: ToDo?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let todo = data {
            label.text = todo.nomTache
            descriptionLabel.text = todo.descriptionTache
            dateLabel.text = todo.dateTache
            
            switchVertGris.setOn(todo.etatTache, animated: true)
            
        }
        
        
    }
}
